function getHostname() {
  return location.hostname.replace(/^www\./, '');
}

function getProfileKey(hostname, profileName) {
  return `autofill_${hostname}_${profileName}`;
}

function autofillFields(savedData) {
  const allInputs = document.querySelectorAll("input, select, textarea");

  allInputs.forEach((el) => {
    const name = el.name || el.id;
    if (!name || el.dataset.autofilled === "true") return;

    const savedValue = savedData[name];
    if (!savedValue) return;

    if (el.type === "radio") {
      if (el.value === savedValue && !el.checked) {
        el.checked = true;
        el.dataset.autofilled = "true";
        el.dispatchEvent(new Event("change", { bubbles: true }));
        el.dispatchEvent(new Event("input", { bubbles: true }));
        el.dispatchEvent(new Event("click", { bubbles: true }));
      }
    } else if (!el.value) {
      el.value = savedValue;
      el.dataset.autofilled = "true";
      el.dispatchEvent(new Event("input", { bubbles: true }));
      el.dispatchEvent(new Event("change", { bubbles: true }));
    }

    el.addEventListener("input", () => {
      delete el.dataset.autofilled;
    });
  });
}

function loadLastUsedProfile() {
  const hostname = getHostname();

  chrome.storage.local.get([`lastProfile_${hostname}`], (res) => {
    const profileName = res[`lastProfile_${hostname}`];
    if (!profileName) return;

    const profileKey = getProfileKey(hostname, profileName);

    chrome.storage.local.get([profileKey], (result) => {
      autofillFields(result[profileKey] || {});
    });
  });
}

loadLastUsedProfile();

const observer = new MutationObserver(() => {
  loadLastUsedProfile();
});
observer.observe(document.body, {
  childList: true,
  subtree: true,
});

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  const hostname = getHostname();

  if (msg.action === "saveProfile") {
    const profileName = msg.profile;
    const profileKey = getProfileKey(hostname, profileName);
    const allFields = document.querySelectorAll("input, textarea, select");
    const data = {};

    allFields.forEach((el) => {
      const key = el.name || el.id;
      if (!key) return;

      if (el.type === "radio") {
        const checked = document.querySelector(`input[name="${el.name}"]:checked`);
        if (checked) data[el.name] = checked.value;
      } else {
        data[key] = el.value;
      }
    });

    const storeObj = {
      [profileKey]: data,
      [`lastProfile_${hostname}`]: profileName
    };

    chrome.storage.local.set(storeObj, () => {
      showToast(`Profil "${profileName}" berhasil disimpan!`);
      sendResponse({ success: true });
    });

    return true;
  }

  if (msg.action === "loadProfile") {
    const profileName = msg.profile;
    const profileKey = getProfileKey(hostname, profileName);

    chrome.storage.local.get([profileKey], (res) => {
      autofillFields(res[profileKey] || {});
      chrome.storage.local.set({ [`lastProfile_${hostname}`]: profileName });
      showToast(`Profil "${profileName}" berhasil diload!`);
      sendResponse({ success: true });
    });

    return true;
  }

  if (msg.action === "deleteProfile") {
    const profileName = msg.profile;
    const profileKey = getProfileKey(hostname, profileName);

    chrome.storage.local.remove([profileKey], () => {
      showToast(`Profil "${profileName}" berhasil dihapus!`);
      sendResponse({ success: true });
    });

    return true;
  }

  if (msg.action === "getProfiles") {
    chrome.storage.local.get(null, (all) => {
      const profiles = Object.keys(all)
        .filter(k => k.startsWith(`autofill_${hostname}_`))
        .map(k => k.replace(`autofill_${hostname}_`, ''));
      sendResponse({ profiles });
    });

    return true;
  }
});

function showToast(message) {
  const toast = document.createElement("div");
  toast.innerText = message;
  toast.style.position = "fixed";
  toast.style.bottom = "20px";
  toast.style.right = "20px";
  toast.style.background = "#4CAF50";
  toast.style.color = "#fff";
  toast.style.padding = "10px 15px";
  toast.style.borderRadius = "5px";
  toast.style.zIndex = 9999;
  toast.style.boxShadow = "0 0 10px rgba(0,0,0,0.2)";
  document.body.appendChild(toast);
  setTimeout(() => toast.remove(), 3000);
}
