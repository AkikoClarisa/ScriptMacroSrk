
function updateProfiles() {
  chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
    chrome.tabs.sendMessage(tabs[0].id, {action: "getProfiles"}, function(response) {
      const select = document.getElementById('profileSelect');
      select.innerHTML = '';
      (response?.profiles || []).forEach(profile => {
        const opt = document.createElement('option');
        opt.value = profile;
        opt.textContent = profile;
        select.appendChild(opt);
      });
    });
  });
}

document.getElementById('saveBtn').onclick = function() {
  const profile = document.getElementById('newProfileName').value.trim();
  if (!profile) return alert("Masukkan nama profil");
  chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
    chrome.tabs.sendMessage(tabs[0].id, {action: "saveProfile", profile}, () => {
      updateProfiles(); // Tambahkan refresh dropdown setelah simpan
    });
  });
};

document.getElementById('loadBtn').onclick = function() {
  const profile = document.getElementById('profileSelect').value;
  if (!profile) return alert("Pilih profil dulu");
  chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
    chrome.tabs.sendMessage(tabs[0].id, {action: "loadProfile", profile});
  });
};

document.getElementById('deleteBtn').onclick = function() {
  const profile = document.getElementById('profileSelect').value;
  if (!profile) return alert("Pilih profil dulu");
  chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
    chrome.tabs.sendMessage(tabs[0].id, {action: "deleteProfile", profile}, () => {
      updateProfiles(); // Tambahkan refresh dropdown setelah hapus
    });
  });
};

updateProfiles();
