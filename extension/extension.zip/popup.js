// Link Web App Google Sheets
const GAS_URL = 'https://script.google.com/macros/s/AKfycbxacG_CFAOjAdmizNzAHzcIzsWISg7rHOlIdbDjuD6kIg2vjXJwE0-Bth8QVi7hXlp-/exec';

document.getElementById('formJadwal').addEventListener('submit', async (e) => {
    e.preventDefault();

    const dateVal = document.getElementById('tanggal').value; 
    const timeVal = document.getElementById('waktu').value; 
    const nomor = document.getElementById('nomor').value;
    const pesan = document.getElementById('pesan').value;
    const statusDiv = document.getElementById('status');
    const btnSubmit = document.getElementById('btnSubmit');

    // === SISTEM VALIDASI & AUTO CONVERT NOMOR ===
    
    // 1. Hapus semua karakter selain angka (kayak tanda +, -, atau spasi)
    let formatNomor = nomor.replace(/[^0-9]/g, '');
    
    // 2. Kalau nomor diawali angka '0', otomatis ubah jadi '62'
    if (formatNomor.startsWith('0')) {
        formatNomor = '62' + formatNomor.substring(1);
    }

    // 3. Cek final, kalau bukan 62 atau nomor terlalu pendek, tolak!
    if (!formatNomor.startsWith('62') || formatNomor.length < 10) {
        statusDiv.innerHTML = '❌ Nomor tidak valid (Gunakan 08 / 628 / +628)';
        statusDiv.style.color = '#ef4444';
        return;
    }

    // === VALIDASI WAKTU ===
    const [year, month, day] = dateVal.split('-');
    const [hour, minute] = timeVal.split(':');
    const scheduleDate = new Date(year, parseInt(month) - 1, day, hour, minute, 0);

    if (scheduleDate < new Date()) {
        statusDiv.innerHTML = '❌ Waktu tersebut sudah lewat!';
        statusDiv.style.color = '#ef4444';
        return;
    }

    // === PROSES PENGIRIMAN ===
    const bulanIndo = ['Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni', 'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'];
    const namaBulan = bulanIndo[parseInt(month) - 1];

    const idJadwal = `EXT-${Date.now()}`; 
    const timestampData = scheduleDate.getTime();
    const tanggalText = `${day} ${namaBulan} ${year} - ${timeVal} WIB`;

    btnSubmit.innerText = 'Menyimpan...';
    btnSubmit.style.opacity = '0.7';
    btnSubmit.disabled = true;
    statusDiv.innerHTML = ''; 

    try {
        const response = await fetch(GAS_URL, {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: new URLSearchParams({
                action: 'add',
                id: idJadwal,
                timestamp: timestampData,
                tanggalText: tanggalText,
                nomor: formatNomor, // Masukkan nomor yang udah bersih ke database
                pesan: pesan
            })
        });

        if (response.ok) {
            statusDiv.innerHTML = `✅ Berhasil masukan data ke database`;
            statusDiv.style.color = '#10b981'; 
            document.getElementById('formJadwal').reset(); 
        } else {
            statusDiv.innerHTML = `❌ Gagal tersambung ke Database.`;
            statusDiv.style.color = '#ef4444';
        }
    } catch (err) {
        statusDiv.innerHTML = `❌ Error sistem koneksi.`;
        statusDiv.style.color = '#ef4444';
    }

    btnSubmit.innerText = 'Kirim Jadwal';
    btnSubmit.style.opacity = '1';
    btnSubmit.disabled = false;
});
