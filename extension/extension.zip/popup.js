// Link Web App lu udah otomatis terpasang
const GAS_URL = 'https://script.google.com/macros/s/AKfycbxacG_CFAOjAdmizNzAHzcIzsWISg7rHOlIdbDjuD6kIg2vjXJwE0-Bth8QVi7hXlp-/exec';

document.getElementById('formJadwal').addEventListener('submit', async (e) => {
    e.preventDefault();

    const dateVal = document.getElementById('tanggal').value; // Hasil: YYYY-MM-DD
    const timeVal = document.getElementById('waktu').value; // Hasil: HH:MM
    const nomor = document.getElementById('nomor').value;
    const pesan = document.getElementById('pesan').value;

    // Pecah format tanggal dan waktu
    const [year, month, day] = dateVal.split('-');
    const [hour, minute] = timeVal.split(':');

    // Bikin objek waktu standar
    const scheduleDate = new Date(year, parseInt(month) - 1, day, hour, minute, 0);

    // Validasi masa lalu
    if (scheduleDate < new Date()) {
        document.getElementById('status').innerHTML = '❌ Waktu sudah lewat bro!';
        return;
    }

    const bulanIndo = ['Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni', 'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'];
    const namaBulan = bulanIndo[parseInt(month) - 1];

    // Bikin format yang bisa dibaca Google Sheets
    const idJadwal = `EXT-${Date.now()}`; // Kasih tanda "EXT" biar tau ini dari Ekstensi
    const timestampData = scheduleDate.getTime();
    const tanggalText = `${day} ${namaBulan} ${year} - ${timeVal} WIB`;

    const btnSubmit = document.getElementById('btnSubmit');
    btnSubmit.innerText = 'Menyinkronkan...';
    btnSubmit.disabled = true;

    try {
        const response = await fetch(GAS_URL, {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: new URLSearchParams({
                action: 'add',
                id: idJadwal,
                timestamp: timestampData,
                tanggalText: tanggalText,
                nomor: nomor,
                pesan: pesan
            })
        });

        if (response.ok) {
            document.getElementById('status').innerHTML = `✅ Jadwal Masuk Excel!<br><small style="color:green">Akan ditarik otomatis oleh Bot Termux.</small>`;
            document.getElementById('formJadwal').reset(); // Bersihin form otomatis
        } else {
            document.getElementById('status').innerHTML = `❌ Gagal tersambung ke Database.`;
        }
    } catch (err) {
        document.getElementById('status').innerHTML = `❌ Error sistem.`;
    }

    btnSubmit.innerText = 'Kirim ke Database';
    btnSubmit.disabled = false;
});
